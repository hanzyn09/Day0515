package com.the.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FileBoardDeleteServiceImpl implements FileBoardService {

	@Override
	public String excute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String _no=request.getParameter("no");
		long no=Long.parseLong(_no);
		//먼저 filetable정보 삭제
		int result=fileBoardDao.fileDeleteByBno(no);
		System.out.println("첨부파일 "+result+"개 삭제");
		fileBoardDao.fboardDeleteById(no);
		response.sendRedirect("list");
		return null;
	}

}
