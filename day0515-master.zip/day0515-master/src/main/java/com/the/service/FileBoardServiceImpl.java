package com.the.service;

import java.io.File;
import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.the.domain.dto.FileBoard;
import com.the.domain.dto.Filetable;

public class FileBoardServiceImpl implements FileBoardService {

	@Override
	public String excute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		//문자열데이터는 파라미터로 받고
		String subject=request.getParameter("subject");
		String content=request.getParameter("content");
		//System.out.println(subject);
		//System.out.println(content);
		FileBoard fileBoard=new FileBoard();
		fileBoard.setSubject(subject);//제목
		fileBoard.setContent(content);//내용
		
		//파일데이터는 Part를 이용해서 받으시면 됩니다.
		Part filePart=request.getPart("file");
		long filesize=filePart.getSize();
		//파일이 존재할때만 작업...
		if(filesize>0) {
			String fileName=filePart.getSubmittedFileName();
			String root="C:/weekend/workspace/day0515/src/main/webapp";
			String path="/upload/";
			//File filePath=new File("/upload/");
			//String path=filePath.getAbsolutePath();
			//System.out.println("path:"+path);
			//파일 업로드는 선택사항
			//파일이 존재할때...
			String filePath=root+path;
			
			filePart.write(filePath+fileName);
			System.out.println("파일업로드 완료!");
			//파일정보 셋팅
			String fileurl=path+fileName;
			//제목,내용, 파일{파일이름, 경로, 사이즈}
			Filetable filetable=new Filetable();
			filetable.setFilename(fileName);
			filetable.setFilesize(filesize);
			filetable.setFileurl(fileurl);
			
			fileBoard.setFile(filetable);//파일객체//선택적이다...
		}
		
		
		fileBoardDao.fileBoardInsert(fileBoard);
		/*
		// 파일포함한 다른정보 모두 확인 할때 처리..
		Collection<Part> parts=request.getParts();
		for(Part part:parts) {
			//part.getName(); //웹에서 넘겨주는 data저장 이름
		}
		*/
		
		//저장후 (DB에서 list정보 갖고) list페이지이동
		
		//절대경로 이동방법
		//response.sendRedirect(request.getContextPath()+"/fboard/list");
		//상대경로 이동방법
		response.sendRedirect("list");
		return null;
	}

}
