package com.the.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.the.dao.FileBoardDao;

public interface FileBoardService {
	//interface 모든멤버필드는 (생략이 되어있어도)final static 입니다.
	public FileBoardDao fileBoardDao=new FileBoardDao();
		
	public String excute(HttpServletRequest request, HttpServletResponse response)
			 throws ServletException, IOException ;

}
