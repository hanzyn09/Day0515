package com.the.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.the.config.MaybatisConfig;
import com.the.domain.dto.FileBoard;
import com.the.domain.dto.Filetable;

public class FileBoardDao {
	//DB에 접근하기위해 ServletContext에(또는 싱글톤으로 ) 저장된 객체를 사용 
	private SqlSessionFactory sqlSessionFactory;
	public FileBoardDao() {
		sqlSessionFactory=MaybatisConfig.getInstance();
	}
	public void fileBoardInsert(FileBoard fileBoard) {
		//System.out.println("DB실행전 no : "+fileBoard.getNo());
		SqlSession sqlSession=sqlSessionFactory.openSession();
		//파일보드입력
		sqlSession.insert("boardMapper.insert", fileBoard);
		//파일이 존재하면 파일테이블도 입력
		//System.out.println("DB실행후 no : "+fileBoard.getNo());
		
		//파일테이터 저장
		Filetable fileinfo=fileBoard.getFile();
		//파일이 존재할때
		if(fileinfo!=null) {
			fileinfo.setBno(fileBoard.getNo());
			sqlSession.insert("fileMapper.insert", fileinfo);
		}
		
		sqlSession.commit();
		sqlSession.close();
		
	}
	
	public List<FileBoard> getListAll() {
		SqlSession sqlSession=sqlSessionFactory.openSession();
		
		List<FileBoard> result=sqlSession.selectList("boardMapper.listAll");
		for(FileBoard board:result) {
			//board.getNo() == 파일테이블의 bno
			long bno=board.getNo();
			Filetable fileResult=sqlSession.selectOne("fileMapper.matchBno", bno);
			//System.out.println(fileResult);
			
			board.setFile(fileResult);
		}
		sqlSession.close();
		
		return result;
	}
	
	public FileBoard getDetail(long no) {
		SqlSession sqlSession=sqlSessionFactory.openSession();
		
		FileBoard result=sqlSession.selectOne("boardMapper.detail", no);
		//파일테이블
		long bno=no;
		Filetable fileResult=sqlSession.selectOne("fileMapper.matchBno", bno);
		//파일결과 셋팅
		result.setFile(fileResult);
		
		sqlSession.close();
		return result;
	}
	public void fileDelete(long fno) {
		SqlSession sqlSession=sqlSessionFactory.openSession(true);
		sqlSession.delete("fileMapper.delete", fno);
		
		sqlSession.close();
	}
	public int fileDeleteByBno(long bno) {
		SqlSession sqlSession=sqlSessionFactory.openSession(true);
		//변경된 row개수 리턴
		int result=sqlSession.delete("fileMapper.deleteByBno", bno);
		
		sqlSession.close();
		return result;
		
	}
	public void fboardDeleteById(long no) {
		SqlSession sqlSession=sqlSessionFactory.openSession(true);
		sqlSession.delete("boardMapper.deleteById", no);
		
		sqlSession.close();
		
	}

}
