package com.the.controller;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

import com.the.service.FileBoardDeleteServiceImpl;
import com.the.service.FileBoardDetailServiceImpl;
import com.the.service.FileBoardFileDeleteServiceImpl;
import com.the.service.FileBoardListServiceImpl;
import com.the.service.FileBoardService;
import com.the.service.FileBoardServiceImpl;

@MultipartConfig(
		fileSizeThreshold = 1024*1024*1,
		location = "/",
		maxFileSize = 1024*1024*10,
		maxRequestSize = 1024*1024*10
)
@WebServlet("/fboard/*")
public class FileBoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    //ServletFileUpload 
	FileBoardService fileBoardService;
	
	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uri=request.getRequestURI();
		String[] strs=uri.split("[/]");
		String key=strs[strs.length-1];
		String path=null;
		if(key.equals("write")) {
			fileBoardService=new FileBoardServiceImpl();
			path=fileBoardService.excute(request, response);
		}else if(key.equals("list")) {
			fileBoardService=new FileBoardListServiceImpl();
			path=fileBoardService.excute(request, response);
		}else if(key.equals("detail")) {
			fileBoardService=new FileBoardDetailServiceImpl();
			path=fileBoardService.excute(request, response);
		}else if(key.equals("file-del")) {
			fileBoardService=new FileBoardFileDeleteServiceImpl();
			path=fileBoardService.excute(request, response);
		}else if(key.equals("delete")) {
			fileBoardService=new FileBoardDeleteServiceImpl();
			path=fileBoardService.excute(request, response);
		}
		
		if(path!=null) {
			request.getRequestDispatcher(path).forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
