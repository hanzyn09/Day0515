package com.the.config;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MaybatisConfig {
	
	private static SqlSessionFactory sqlSessionFactory;
	public static SqlSessionFactory getInstance(){
		//한번만 실행시키도록
		if(sqlSessionFactory==null)new MaybatisConfig();
		return sqlSessionFactory;
	}
	private MaybatisConfig(){
		String resource = "mybatis/mybatis-config.xml";
		InputStream inputStream=null;
		try {
			inputStream = Resources.getResourceAsStream(resource);
		} catch (IOException e) {
			e.printStackTrace();
		}
		sqlSessionFactory =
		  new SqlSessionFactoryBuilder().build(inputStream);
	}

}
